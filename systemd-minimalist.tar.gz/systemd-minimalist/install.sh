#!/bin/bash
echo "--- Processing systemd-minimalist (Generic Profile) ---"

# 1. Identify package manager and install core dependencies
if command -v apt &> /dev/null; then
    sudo apt update && sudo apt install -y cronie rsyslog chrony
elif command -v pacman &> /dev/null; then
    sudo pacman -S --noconfirm cronie rsyslog chrony
elif command -v dnf &> /dev/null; then
    sudo dnf install -y cronie rsyslog chrony
fi

# 2. Lighten systemd: Mask Timers (Automated background maintenance)
sudo systemctl mask logrotate.timer man-db.timer dpkg-db-backup.timer apt-daily.timer \
apt-daily-upgrade.timer fstrim.timer anacron.timer systemd-tmpfiles-clean.timer

# 3. Lighten systemd: Mask heavy/unnecessary Services and Sockets
sudo systemctl mask --now ModemManager switcheroo-control avahi-daemon avahi-daemon.socket \
colord.service accounts-daemon.service

# 4. Limit virtual terminals (TTYs) to 2
sudo systemctl mask getty@tty3.service getty@tty4.service getty@tty5.service getty@tty6.service

# 5. Apply optimized configuration files (RAM logs and TTY limits)
sudo cp logind.conf /etc/systemd/logind.conf
sudo cp journald.conf /etc/systemd/journald.conf

# 6. Reload systemd to apply changes
sudo systemctl daemon-reload
sudo systemctl restart systemd-journald
sudo systemctl restart systemd-logind

echo "--- systemd-minimalist optimization complete ---"
